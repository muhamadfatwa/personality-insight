# Revisi Pertanyaan Personality Insight V3 — Tahap 2

## Perubahan

Tahap 2 menulis ulang 16 pertanyaan yang masih berpotensi mencampur dimensi atau terlalu dipengaruhi konteks hubungan, konflik, atau gaya komunikasi.

| No. | Dimensi | Fokus revisi |
|---:|---|---|
| 6 | I/E | Memikirkan sebelum berbicara vs berpikir sambil berbicara |
| 8 | I/E | Bekerja mandiri lalu berbagi hasil vs bertukar pikiran selama proses |
| 18 | T/F | Menilai alasan/bukti vs memperhatikan perasaan/konteks penyampaian |
| 19 | T/F | Standar dan perbaikan masalah vs dampak manusia dan hubungan |
| 23 | T/F | Kejelasan dan spesifikasi masukan vs kesiapan/perasaan penerima |
| 24 | T/F | Kriteria dan konsekuensi konsisten vs nilai dan kebutuhan pihak terdampak |
| 25 | J/P | Menyusun rencana pengganti vs menyesuaikan sambil mengamati |
| 35 | J/P | Tahapan terencana vs tujuan umum dengan proses fleksibel |
| 36 | J/P | Rencana perbaikan terstruktur vs eksplorasi pendekatan |
| 39 | I/E | Percakapan mendalam dengan sedikit orang vs interaksi luas |
| 40 | I/E | Memulihkan energi sendiri vs mendapat energi dari interaksi |
| 43 | I/E | Menunggu momen bicara vs memulai percakapan |
| 44 | T/F | Konsistensi alasan/konsekuensi vs nilai dan dampak manusia |
| 45 | T/F | Konsistensi dan keadilan aturan vs dampak terhadap kesejahteraan |
| 46 | J/P | Tonggak dan pemantauan progres vs tujuan fleksibel |
| 47 | I/E | Percakapan terbatas lalu waktu sendiri vs interaksi luas yang memberi energi |
| 50 | N/S | Konsep/pola/kemungkinan vs fakta/contoh/penerapan |

Catatan: ada 17 nomor yang direvisi pada tabel, karena pertanyaan 50 juga disempurnakan untuk mengurangi campuran preferensi terhadap hal baru dengan toleransi risiko.

## Pemeriksaan teknis
- Jumlah pertanyaan tetap 50.
- Struktur setiap pertanyaan tetap `[teks, opsi A, opsi B, label A, label B]`.
- Kode `app.js` tidak diubah pada tahap ini.
- Validasi sintaks `app.js` dan `data.js` dijalankan setelah perubahan.
- Perubahan ini memperbaiki kecocokan isi secara konseptual; belum merupakan validasi psikometrik empiris.
