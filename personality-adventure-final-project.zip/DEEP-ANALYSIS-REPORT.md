# Laporan Analisis Mendalam — Psychology Adventure

## Fitur
- Menampilkan hingga dua kombinasi kecenderungan yang didukung pola skor dan pilihan.
- Setiap kombinasi memiliki penjelasan singkat tentang bagaimana kedua kecenderungan dapat muncul bersamaan.
- Kombinasi hanya dipertimbangkan jika masing-masing kecenderungan muncul positif pada setidaknya dua pilihan, dan skornya berada cukup dekat dengan kecenderungan teratas.
- Setiap kombinasi menampilkan contoh pilihan yang mendukung masing-masing sisi kombinasi.
- Jika data pilihan tidak mendukung kombinasi yang cukup kuat, UI menampilkan pesan netral, bukan memaksakan kesimpulan.
- Ringkasan utama, profil cerita, dan bukti pilihan tetap ditampilkan.

## Contoh kombinasi yang tersedia
- Berani tetapi tetap waspada
- Penasaran dan reflektif
- Mandiri dengan pertimbangan
- Peduli sekaligus waspada
- Terbuka, tetapi tidak langsung menerima
- Mencari tahu dengan arah
- Berani mengambil jalan sendiri
- Mengutamakan keamanan dan persiapan
- Membangun hubungan dengan kepedulian
- Merenung lalu menyusun langkah
- Penasaran dan suka menjelajah sendiri
- Menjaga batas aman

## Pengujian
- `node --check app.js`: lulus.
- Elemen HTML `journeyCombinations` tersedia.
- Simulasi fungsi analisis menggunakan data perjalanan contoh berhasil menghasilkan kombinasi dan bukti pilihan untuk kedua kecenderungan.
- Pengujian browser langsung belum dilakukan.

## Batasan
Ini adalah refleksi berbasis pilihan dalam cerita fiksi, bukan alat diagnosis atau penilaian psikologis yang tervalidasi. Skor adalah aturan desain cerita dan tidak boleh dianggap sebagai pengukuran ilmiah kepribadian.

## Gambar
Paket tidak menyertakan gambar yang dikelola manual. Pertahankan folder `images/adventure/forbidden/` dan `images/adventure/0317/`.
