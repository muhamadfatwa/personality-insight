# Revisi Pertanyaan Personality Insight V3 — Tahap 1

Tujuh pertanyaan dengan pemetaan yang lemah telah ditulis ulang. Jumlah pertanyaan tetap 50, struktur data tetap sama, dan kode pemetaan skor tetap menggunakan dimensi yang sudah ada.

| No. | Dimensi | Fokus baru |
|---:|---|---|
| 34 | T/F | Konsistensi logika/prinsip vs nilai dan dampak terhadap orang |
| 37 | T/F | Alasan dan bukti vs nilai dan kebutuhan pihak terdampak |
| 38 | T/F | Logika keputusan vs niat dan dampak manusia |
| 41 | T/F | Kriteria konsisten vs konteks dan kebutuhan individual |
| 42 | T/F | Evaluasi proses/logika vs nilai/kebutuhan yang terabaikan |
| 48 | T/F | Kriteria objektif vs kebutuhan pihak terdampak |
| 49 | T/F | Mengurai solusi vs memahami perasaan dan prioritas |

## Pengujian yang dilakukan
- `data.js` berhasil diparse sebagai JSON setelah pembungkus `const DATA=...` dibaca.
- Jumlah pertanyaan tetap 50.
- Setiap pertanyaan memiliki dua opsi dan dua label skor.
- Pemetaan dimensi pertanyaan tidak berubah.
- Ini adalah perbaikan konsistensi isi, bukan validasi psikometrik. Pertanyaan T/F masih merupakan pilihan paksa dan hasilnya sebaiknya dibaca sebagai kecenderungan, bukan diagnosis atau penilaian mutlak.
