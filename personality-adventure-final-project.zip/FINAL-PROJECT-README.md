# Psychology Adventure — Final Project Package

## Isi rilis
- Personality Insight V3 beserta 50 pertanyaan dan profil hasil.
- Psychology Adventure dengan dua cerita aktif:
  1. The Forbidden Forest (10 adegan)
  2. Kota yang Berhenti pada Pukul 03:17 (10 adegan)
- Refleksi khusus setelah setiap pilihan (60 penjelasan pilihan).
- Analisis akhir dengan kecenderungan utama, bukti pilihan, dan kombinasi kecenderungan jika didukung pola.
- Laporan audit dan revisi pertanyaan.

## Pengujian yang sudah dilakukan
- `node --check app.js`: lulus.
- `node --check data.js`: lulus.
- Struktur Adventure: 2 cerita × 10 adegan × 3 pilihan = 60 pilihan.
- Setiap pilihan pada 20 adegan memiliki refleksi khusus yang berbeda dari pilihan lain dalam adegan yang sama.
- Setiap pilihan memiliki skor menggunakan dimensi yang dikenal sistem.
- Fungsi analisis mendalam diuji dengan contoh perjalanan di Node.js; kombinasi yang didukung menghasilkan contoh pilihan.
- Pengujian browser langsung tidak dapat diselesaikan di lingkungan ini karena akses browser ke server/file lokal diblokir oleh kebijakan lingkungan. Silakan uji di browser lokal Anda setelah mengekstrak ZIP.

## Menjalankan proyek
1. Ekstrak ZIP.
2. Buka `index.html` di browser. Jika browser membatasi file lokal, jalankan melalui server lokal sederhana atau hosting statis.
3. Pastikan file `app.js`, `data.js`, dan `style.css` berada di folder yang sama dengan `index.html`.

## Aset gambar yang dikelola manual
ZIP ini tidak menyertakan gambar yang sebelumnya diunduh manual. Salin folder gambar milik Anda ke struktur berikut:
- `images/adventure/forbidden/scene-01.png` sampai `scene-10.png`
- `images/adventure/0317/scene-01.png` sampai `scene-10.png`

Tanpa folder tersebut, fitur cerita tetap dapat dibaca tetapi ilustrasi scene/cover yang dirujuk tidak akan tampil.

## Batasan penting
Psychology Adventure adalah pengalaman cerita interaktif untuk hiburan dan refleksi diri. Skor dan interpretasi dirancang untuk mekanik cerita dan bukan instrumen psikologi klinis atau diagnosis. Pilihan tunggal tidak cukup untuk menyimpulkan kepribadian seseorang.
