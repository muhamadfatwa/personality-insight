# Laporan Uji Tahap 3 — Personality Insight V3

Tanggal uji: 10 Oktober 2026

## Ringkasan

- `app.js` dan `data.js` lolos pemeriksaan sintaks Node.js (`node --check`).
- `data.js` memuat tepat 50 pertanyaan dan 16 profil kepribadian.
- Format semua pertanyaan valid: 5 elemen per pertanyaan, teks terisi, dan dua pilihan memetakan ke label dimensi yang berbeda.
- Tidak ditemukan pertanyaan yang teksnya duplikat secara persis.
- Semua 16 kombinasi tipe tersedia di `profiles`.
- Pemeriksaan referensi DOM menemukan 43 ID yang dipakai melalui `$()` dan tidak menemukan ID yang hilang dari `index.html`.
- Simulasi 200.000 pola jawaban acak menghasilkan seluruh 16 tipe. Dalam simulasi ini, tiap tipe muncul di sekitar 12,5% sampel; ini hanya uji perilaku algoritme, bukan validasi psikometri atau prediksi distribusi pengguna nyata.
- Pada 200.000 percobaan membalik satu jawaban yang dipilih secara acak, tipe akhir berubah pada sekitar 22,35% percobaan. Ini merupakan uji sensitivitas sintetis, bukan ukuran validitas tes.

## Uji cerita Personality Adventure

Kedua cerita aktif diperiksa secara menyeluruh dengan enumerasi semua kombinasi pilihan (3 pilihan untuk masing-masing dari 10 adegan = 59.049 kombinasi per cerita).

| Cerita | Adegan | Pilihan per adegan | Kombinasi diuji | Hasil yang dapat dicapai |
|---|---:|---:|---:|---:|
| The Forbidden Forest | 10 | 3 | 59.049 | 5 dari 5 profil |
| Kota yang Berhenti pada Pukul 03:17 | 10 | 3 | 59.049 | 5 dari 5 profil |

Tidak ditemukan kunci skor yang tidak dikenal dalam pilihan cerita. Distribusi hasil memang tidak merata karena bobot profil berbeda; algoritme deterministik tetap membuat seluruh hasil bisa dicapai.

## Perbaikan yang diterapkan

Narasi insight sementara sebelumnya menentukan sisi dimensi dengan aturan `>=`, sedangkan label `miniType` menggunakan pemecah seri berbasis jawaban tertentu. Dalam situasi skor seri, narasi dan label sementara berpotensi tidak konsisten. Narasi kini menggunakan huruf dari tipe sementara yang sama agar keduanya selaras.

## Batasan pengujian

Ini adalah pemeriksaan sintaks, struktur data, simulasi algoritme, dan enumerasi kombinasi pilihan cerita. Situs belum diuji melalui browser nyata pada berbagai ukuran layar/perangkat dalam proses ini. Simulasi jawaban acak juga tidak membuktikan bahwa hasil tes valid secara psikologis.

## Catatan aset gambar

ZIP ini tidak menambahkan file gambar adegan. Pertahankan folder gambar yang sudah disiapkan secara manual dengan struktur:

- `images/adventure/forbidden/scene-01.png` sampai `scene-10.png`
- `images/adventure/0317/scene-01.png` sampai `scene-10.png`
