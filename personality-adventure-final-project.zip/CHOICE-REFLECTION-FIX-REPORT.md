# Perbaikan Refleksi Pilihan Psychology Adventure

## Masalah
Penjelasan setelah memilih di scene berbeda menggunakan teks generik berdasarkan skor trait. Karena itu, beberapa pilihan di adegan berbeda menampilkan penjelasan yang sama atau sangat mirip.

## Perbaikan
- Ditambahkan 60 refleksi khusus: 30 pilihan di *The Forbidden Forest* dan 30 pilihan di *Kota yang Berhenti pada Pukul 03:17*.
- Setiap refleksi terhubung ke pilihan tertentu pada adegan tertentu, sehingga kompas, mengamati rumah, mengikuti orang asing, merekam kejadian, dan pilihan lain tidak sekadar mengulang kalimat generik.
- Penjelasan tetap berupa kemungkinan kecenderungan, bukan diagnosis atau kepastian tentang karakter pemain.
- Skor, bobot jawaban, hasil akhir, dan jalur gambar tidak diubah.
- Refleksi trait generik tetap tersedia sebagai fallback untuk cerita baru yang belum memiliki teks khusus.

## Pengujian
- `node --check app.js`: lulus.
- 20 scene ditemukan, masing-masing berisi 3 pilihan.
- 60 refleksi scene-spesifik ditemukan dan seluruh teksnya unik.
- Tes tampilan langsung di browser belum dijalankan.

## Catatan gambar
Paket ini tidak menyertakan gambar yang dikelola manual. Pertahankan folder `images/adventure/forbidden/` dan `images/adventure/0317/` yang sudah ada.
