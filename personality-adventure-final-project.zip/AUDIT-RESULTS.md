# Personality Insight V3 — Audit Penilaian

## Temuan sebelum perbaikan
- Terdapat 50 pertanyaan dan 16 profil hasil.
- Distribusi pertanyaan per dimensi: I/E = 12, N/S = 9, T/F = 17, J/P = 12.
- Fungsi `type()` sebelumnya memakai `>=`, sehingga seri selalu memilih I, N, T, dan J. Untuk dimensi I/E dan J/P, ini memberi bias kepada I dan J karena masing-masing memiliki 12 pertanyaan dan dapat seri.

## Perbaikan
- Jika skor seri, I/E memakai jawaban pada pertanyaan energi yang langsung (pertanyaan 7; index 6).
- Jika skor seri, N/S memakai jawaban pada pertanyaan konsep/pengalaman yang langsung (pertanyaan 9; index 8).
- Jika skor seri, T/F memakai jawaban pada pertanyaan keputusan yang langsung (pertanyaan 17; index 16).
- Jika skor seri, J/P memakai jawaban pada pertanyaan struktur proyek yang langsung (pertanyaan 26; index 25).
- Hasil dimensi pada layar insight dan halaman akhir memakai aturan tie-breaker yang sama.
- Jawaban yang sama tetap menghasilkan tipe yang sama; tidak ada randomisasi.

## Pengujian
- `node --check app.js`: lulus.
- Semua 16 profil tersedia di `data.js`.
- Enumerasi seluruh kombinasi jawaban untuk tiap dimensi (2^12, 2^9, 2^17, dan 2^12) dengan tie-breaker: setiap sisi dimensi memiliki peluang tepat 50% jika setiap pilihan A/B dianggap sama mungkin.
- Dalam model teoretis jawaban acak dan independen, peluang setiap dari 16 tipe menjadi 6,25%. Ini bukan prediksi distribusi pengguna nyata; preferensi dan pola jawaban nyata dapat membuat hasil berbeda.
- Semua A menghasilkan INTJ; semua B menghasilkan ESFP, sebagaimana sesuai dengan arah pilihan di instrumen saat ini.

## Catatan
ZIP ini tidak menyertakan ilustrasi Adventure. Pertahankan folder gambar milik project yang sudah ada saat mengganti `app.js`.
