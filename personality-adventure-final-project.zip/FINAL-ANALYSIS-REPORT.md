# Laporan Analisis Akhir — Psychology Adventure

## Fitur baru
- Hasil akhir sekarang menambahkan ringkasan pola berdasarkan skor pilihan pemain di sepanjang cerita.
- Menampilkan satu atau beberapa kecenderungan teratas (termasuk jika ada skor seri).
- Menghubungkan pola tersebut dengan profil hasil cerita yang sudah ada.
- Menampilkan contoh pilihan dari adegan yang ikut menyumbang pada kecenderungan teratas.
- Riwayat pilihan sekarang menyimpan judul adegan, teks pilihan, skor kontribusi, dan refleksi pilihan.
- Skor, bobot pilihan, profil hasil, dan nama cerita tidak diubah.

## Pengujian yang dilakukan
- `node --check app.js`: lulus.
- Elemen HTML untuk ringkasan, daftar kecenderungan, dan bukti pilihan tersedia.
- Riwayat pilihan terstruktur tersimpan di `adventureChoices`.
- Fungsi analisis akhir dan fungsi penyelesaian cerita masing-masing hanya didefinisikan satu kali.
- Pemeriksaan ini tidak menggantikan uji interaksi langsung di browser.

## Batasan interpretasi
Analisis merangkum pola dalam konteks cerita fiksi, bukan hasil tes psikologi klinis atau penilaian kepribadian yang tervalidasi. Hasil dipengaruhi pilihan yang tersedia, konteks adegan, dan bobot skor yang ditetapkan pembuat cerita.

## Aset gambar
ZIP tidak menyertakan gambar yang dikelola manual. Pertahankan folder:
- `images/adventure/forbidden/`
- `images/adventure/0317/`
