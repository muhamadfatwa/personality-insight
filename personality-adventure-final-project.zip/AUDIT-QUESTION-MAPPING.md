# Audit Isi Pertanyaan Personality Insight V3

## Ringkasan

- Total: 50 pertanyaan, 16 tipe hasil.
- Pertanyaan 1–33 sebagian besar tersusun dalam blok dimensi yang jelas.
- Pertanyaan 34–50 adalah pertanyaan tambahan yang lebih banyak mencampur konstruk. Beberapa pemetaan skornya tidak kuat.
- Audit ini merupakan tinjauan isi dan konsistensi logika, bukan validasi psikometrik klinis atau bukti bahwa tes setara dengan instrumen MBTI resmi.

## Rekomendasi utama

1. Jangan mengubah semua pertanyaan sekaligus.
2. Pertahankan dahulu pertanyaan yang kuat.
3. Tinjau ulang pertanyaan yang diberi label **Lemah** atau **Lemah-sedang**, terutama nomor 34, 37, 38, 41, 42, 48, dan 49.
4. Pertanyaan yang mencampur gaya komunikasi, batas pribadi, respons terhadap konflik, kebutuhan pengakuan, atau coping sebaiknya tidak dipetakan langsung ke T/F atau I/E tanpa alasan yang lebih kuat.
5. Jika ingin mempertahankan 50 pertanyaan, pertanyaan tambahan bisa ditulis ulang agar mengukur salah satu dari empat dimensi dengan pasangan opsi yang lebih seimbang.
6. Setelah revisi, jalankan kembali uji distribusi tipe dan pemeriksaan sensitivitas: ubah satu jawaban pada satu waktu lalu lihat apakah hasil berubah secara masuk akal.

## Catatan tentang interpretasi

Tipe empat huruf adalah ringkasan kecenderungan, bukan diagnosis atau deskripsi mutlak. Jangan menyatakan hasil sebagai kepastian ilmiah sebelum ada uji reliabilitas dan validitas pada sampel pengguna.

## Tinjauan per pertanyaan

| No. | Dimensi saat ini | Penilaian | Catatan |
|---:|---|---|---|
| 1 | I/E | Baik | Preferensi mengamati dulu vs cepat berinteraksi cukup jelas. |
| 2 | I/E | Kuat | Pertanyaan energi setelah interaksi sesuai dengan dimensi. |
| 3 | I/E | Baik | Memproses sendiri vs mengembangkan ide lewat diskusi. |
| 4 | I/E | Baik | Perilaku sosial cukup jelas, meski bisa dipengaruhi situasi. |
| 5 | I/E | Baik | Mematangkan ide sendiri vs berdiskusi. |
| 6 | I/E | Lemah-sedang | Aktif tanpa pusat perhatian tidak otomatis introvert; opsi E lebih jelas. |
| 7 | I/E | Kuat | Pemulihan energi sendiri vs interaksi. |
| 8 | I/E | Sedang | Cara bekerja mandiri vs berdiskusi dapat dipengaruhi jenis pekerjaan. |
| 9 | N/S | Kuat | Konsep dan hubungan besar vs contoh nyata dan aplikasi. |
| 10 | N/S | Lemah-sedang | Mencari pola/penyebab vs fakta/langkah praktis, tetapi konteks mendengar masalah juga menyentuh empati. |
| 11 | N/S | Baik | Kemungkinan masa depan vs rencana konkret realistis. |
| 12 | N/S | Kuat | Mengembangkan kemungkinan vs memilih bentuk praktis. |
| 13 | N/S | Baik | Mengapa sesuatu bekerja vs keterampilan penggunaan. |
| 14 | N/S | Kuat | Konsep/teori vs fakta/pengalaman/contoh. |
| 15 | N/S | Baik | Mencari pola vs pengalaman yang terbukti. |
| 16 | N/S | Kuat | Prinsip/gambaran besar vs langkah konkret. |
| 17 | T/F | Kuat | Logika-konsekuensi vs nilai dan dampak pada orang. |
| 18 | T/F | Lemah-sedang | Menilai validitas kritik vs cara penyampaian bukan pasangan T/F yang bersih; bisa sama-sama penting. |
| 19 | T/F | Sedang | Langsung mengoreksi vs menjaga perasaan; gaya komunikasi ikut tercampur. |
| 20 | T/F | Baik | Solusi logis vs solusi yang mempertimbangkan penerimaan pihak. |
| 21 | T/F | Baik | Efisiensi vs kenyamanan emosional. |
| 22 | T/F | Kuat | Kekuatan logika argumen vs memahami orang yang terlibat. |
| 23 | T/F | Sedang | Jujur/langsung vs halus; lebih mengukur gaya penyampaian daripada dasar keputusan. |
| 24 | T/F | Sedang | Menjalankan keputusan yang dianggap benar vs menyesuaikan; bisa mengukur ketegasan/konflik. |
| 25 | J/P | Sedang | Perubahan rencana dan fleksibilitas, tetapi opsi A mengukur emosi terganggu. |
| 26 | J/P | Kuat | Struktur target vs membiarkan proses berkembang. |
| 27 | J/P | Baik | Memulai lebih awal vs fleksibilitas deadline. |
| 28 | J/P | Kuat | Lingkungan terstruktur vs fleksibel. |
| 29 | J/P | Kuat | Keputusan final vs membuka kemungkinan. |
| 30 | J/P | Kuat | Itinerary vs arah umum dan spontanitas. |
| 31 | J/P | Baik | Membuat sistem vs eksplorasi dulu. |
| 32 | J/P | Kuat | Menyelesaikan sesuai rencana vs kemungkinan tak terduga. |
| 33 | J/P | Baik | Mengejar target vs menyesuaikan keadaan. |
| 34 | T/F | Lemah | Membuktikan kemampuan lewat hasil vs membiarkan diremehkan tidak jelas mengukur T/F; lebih dekat ke respons terhadap evaluasi/ketegasan. |
| 35 | J/P | Lemah-sedang | Visi dan mengarahkan orang vs kebebasan cara kerja; bisa mengukur gaya kepemimpinan, bukan J/P. |
| 36 | J/P | Sedang | Membuat rencana baru vs mempertanyakan asumsi menggabungkan perencanaan dengan pemikiran kritis/N. |
| 37 | T/F | Lemah-sedang | Berbicara saat berbeda pendapat vs mengikuti alur lebih dekat ke asertivitas/sosial, bukan T/F. |
| 38 | T/F | Lemah-sedang | Menjelaskan diri vs membiarkan kesalahpahaman lebih dekat ke komunikasi/konflik, bukan T/F. |
| 39 | I/E | Sedang | Ruang pribadi vs komunikasi intens dalam hubungan; dipengaruhi gaya keterikatan dan norma hubungan. |
| 40 | I/E | Sedang | Memberi ruang vs mengejar memperbaiki; lebih dekat ke respons terhadap jarak/konflik hubungan daripada I/E. |
| 41 | T/F | Lemah | Memutus hubungan vs memberi kesempatan lebih dekat ke batas pribadi/kepercayaan daripada T/F. |
| 42 | T/F | Lemah | Fokus ke langkah berikutnya vs lama memikirkan kesalahan lebih dekat ke coping/refleksi daripada T/F. |
| 43 | E/I | Sedang | Ekspresi marah terlihat vs disembunyikan bukan ukuran langsung introversi/ekstroversi. |
| 44 | F/T | Sedang | Membantu saat sibuk vs mengatakan tidak lebih dekat ke batas pribadi/agreeableness daripada T/F. |
| 45 | T/F | Sedang | Tetap pada keyakinan vs mempertimbangkan mayoritas bisa mengukur independensi/asertivitas. |
| 46 | J/P | Lemah-sedang | Fokus target vs menjaga keseimbangan tidak sepenuhnya J/P; bisa mengukur ambisi/prioritas. |
| 47 | E/I | Sedang | Senang hasil diketahui vs puas sendiri bercampur dengan kebutuhan pengakuan. |
| 48 | T/F | Lemah | Dihormati vs dicintai bukan pasangan T/F yang sepadan; mengukur kebutuhan sosial/nilai pribadi. |
| 49 | T/F | Lemah | Mandiri/kuat vs tenang dengan orang tersayang tidak sepadan; mencampur otonomi dan afiliasi. |
| 50 | N/S | Baik | Cara baru berdasar alasan vs cara lama yang terbukti; relevan, tetapi juga mengukur toleransi risiko. |

## Saran perubahan tahap pertama

Untuk menjaga stabilitas project, saya menyarankan hanya menulis ulang pertanyaan yang pemetaan skornya paling lemah terlebih dahulu. Prioritasnya:

- **Q34:** respons ketika diremehkan
- **Q37:** berbeda pendapat dalam kelompok
- **Q38:** ketika disalahpahami
- **Q41:** seseorang mengecewakan berkali-kali
- **Q42:** respons setelah gagal
- **Q48:** dihormati vs dicintai
- **Q49:** mandiri/kuat vs tenang bersama orang tersayang

Pertanyaan-pertanyaan ini tidak otomatis buruk sebagai bahan refleksi diri; masalahnya adalah pasangan jawabannya tidak mengukur dimensi empat huruf yang sama dengan cukup bersih.
